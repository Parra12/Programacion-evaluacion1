// Define un array de géneros de películas
const generos: string[] = [
    "Musical", 
    "Bélico",
    "Cine Negro",
    "Documental",
    "Ciencia Ficción",
    "Comedia",
    "Romance",
    "Suspenso"
];

// Define un array de países
const paises: string[] = [
    "Ucrania",
    "Iran",
    "México",
    "Venezuela",
    "China",
    "Colombia",
    "India",
    "Israel"
];

// Función para mostrar las listas en el DOM
function mostrarListas(): void {
    // Obtiene los elementos del DOM por ID
    const generosList = document.getElementById("generos-list");
    const paisesList = document.getElementById("paises-list");

    // Verifica que los elementos existan
    if (generosList && paisesList) {
        // Limpia las listas por si ya tienen contenido
        generosList.innerHTML = "";
        paisesList.innerHTML = "";

        // Agrega cada género a la lista
        generos.forEach(genero => {
            const item = document.createElement("li"); // Crea un elemento <li>
            item.className = "list-group-item"; // Aplica clase de Bootstrap
            item.textContent = genero; // Asigna el texto
            generosList.appendChild(item); // Añade a la lista
        });

        // Agrega cada país a la lista
        paises.forEach(pais => {
            const item = document.createElement("li"); // Crea un elemento <li>
            item.className = "list-group-item"; // Aplica clase de Bootstrap
            item.textContent = pais; // Asigna el texto
            paisesList.appendChild(item); // Añade a la lista
        });
    } else {
        // Mensaje de error en consola si los elementos no se encuentran
        console.error("No se encontraron los elementos generos-list o paises-list en el DOM");
    }
}

// Ejecuta la función cuando el DOM esté completamente cargado
document.addEventListener("DOMContentLoaded", mostrarListas);